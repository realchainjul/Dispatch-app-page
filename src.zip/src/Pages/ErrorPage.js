const ErrorPage = () => {
    return(
      <div className = 'error' style ={{padding: '20px'}}>
        <h1>404: Page Not Found</h1>
        <p>Page is not exist.</p>
      </div>
    );
  }