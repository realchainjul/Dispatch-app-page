import React from "react";

const Photos = () => {
  return(
    <h1>Photos</h1>
  );
}

export default Photos;