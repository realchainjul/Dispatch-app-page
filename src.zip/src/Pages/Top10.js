import React from "react";

const Top10 = () => {
  return(
    <h1>Top10</h1>
  );
}

export default Top10;